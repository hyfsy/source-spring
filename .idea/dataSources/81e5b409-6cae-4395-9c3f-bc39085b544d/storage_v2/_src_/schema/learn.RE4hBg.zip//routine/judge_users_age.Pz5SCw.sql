create procedure judge_users_age(INOUT userAge int, OUT userId int, OUT userName varchar(20))
  begin
	if userAge < 50 then
		#mysql存储过程只能获取一条数据
		select id,name,age into userId,userName,userAge from users where age < 50 limit 1;
	else
		select id,name,age into userId,userName,userAge from users where age > 50 limit 1;
	end if;
end;

